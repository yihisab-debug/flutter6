import 'package:dio/dio.dart';
import '../core/api_client.dart';
import '../core/app_constants.dart';
import '../models/ride_model.dart';
import '../models/user_model.dart';
import 'user_repository.dart';

class RideRepository {
  final _dio = ApiClient().dio;
  final _userRepo = UserRepository();
  final _endpoint = AppConstants.ridesEndpoint;

  Future<List<dynamic>> _safeList(Map<String, dynamic> query) async {
    try {
      final response = await _dio.get(_endpoint, queryParameters: query);
      final data = response.data;

      if (data is List) {
        return data;
      }

      return const [];
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) {
        return const [];
      }

      rethrow;
    }
  }

  Future<RideModel> createRide(RideModel ride) async {
    final response = await _dio.post(_endpoint, data: ride.toJson());
    return RideModel.fromJson(response.data);
  }

  Future<RideModel> getRide(String id) async {
    final response = await _dio.get('$_endpoint/$id');
    return RideModel.fromJson(response.data);
  }

  Future<List<RideModel>> getAvailableRides() async {
    final list = await _safeList({
      'status': RideStatus.searching,
      'sortBy': 'createdAt',
      'order': 'desc',
    });
    return list.map((e) => RideModel.fromJson(e)).toList();
  }

  Future<List<RideModel>> getPassengerHistory(String passengerId) async {
    final list = await _safeList({
      'passengerId': passengerId,
      'sortBy': 'createdAt',
      'order': 'desc',
    });
    return list.map((e) => RideModel.fromJson(e)).toList();
  }

  Future<List<RideModel>> getDriverHistory(String driverId) async {
    final list = await _safeList({
      'driverId': driverId,
      'sortBy': 'createdAt',
      'order': 'desc',
    });
    return list.map((e) => RideModel.fromJson(e)).toList();
  }

  Future<RideModel?> getActiveRideForPassenger(String passengerId) async {
    final list = await _safeList({'passengerId': passengerId});
    for (final item in list) {
      final ride = RideModel.fromJson(item);
      if (!ride.isFinished) {
        return ride;
      }
    }
    return null;
  }

  Future<RideModel?> getActiveRideForDriver(String driverId) async {
    final list = await _safeList({'driverId': driverId});
    for (final item in list) {
      final ride = RideModel.fromJson(item);

      if (ride.status == RideStatus.accepted ||
          ride.status == RideStatus.inProgress ||
          ride.status == RideStatus.pickedUp) {
        return ride;
      }
    }
    return null;
  }

  Future<RideModel> acceptRide(String rideId, UserModel driver) async {
    final response = await _dio.put(
      '$_endpoint/$rideId',
      data: {
        'driverId': driver.id,
        'driverName': driver.name,
        'carInfo': driver.carInfo,
        'status': RideStatus.accepted,
      },
    );
    return RideModel.fromJson(response.data);
  }

  Future<RideModel> startRide(String rideId) async {
    final response = await _dio.put(
      '$_endpoint/$rideId',
      data: {'status': RideStatus.inProgress},
    );
    return RideModel.fromJson(response.data);
  }

  Future<RideModel> markPickedUp(String rideId) async {
    final response = await _dio.put(
      '$_endpoint/$rideId',
      data: {'status': RideStatus.pickedUp},
    );
    return RideModel.fromJson(response.data);
  }

  Future<RideModel> markDelivered(RideModel ride) async {
    final passenger = await _userRepo.getUserById(ride.passengerId);
    await _userRepo.updateBalance(
      passenger.id,
      passenger.balance - ride.price,
    );

    final driver = await _userRepo.getUserById(ride.driverId);
    await _userRepo.updateBalance(
      driver.id,
      driver.balance + ride.price,
    );

    final response = await _dio.put(
      '$_endpoint/${ride.id}',
      data: {'status': RideStatus.delivered},
    );
    return RideModel.fromJson(response.data);
  }

  Future<RideModel> completeRide(RideModel ride) async {
    final passenger = await _userRepo.getUserById(ride.passengerId);
    await _userRepo.updateBalance(
      passenger.id,
      passenger.balance - ride.price,
    );

    final driver = await _userRepo.getUserById(ride.driverId);
    await _userRepo.updateBalance(
      driver.id,
      driver.balance + ride.price,
    );

    final response = await _dio.put(
      '$_endpoint/${ride.id}',
      data: {'status': RideStatus.completed},
    );
    return RideModel.fromJson(response.data);
  }

  Future<RideModel> cancelRide(String rideId) async {
    final response = await _dio.put(
      '$_endpoint/$rideId',
      data: {'status': RideStatus.cancelled},
    );
    return RideModel.fromJson(response.data);
  }
}
